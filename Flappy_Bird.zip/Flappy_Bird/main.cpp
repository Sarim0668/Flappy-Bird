﻿#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <iostream>
#include<sstream>
#include"Menu.h"


using namespace sf;
using namespace std;

const int cell_size = 64;
const float cameraLerpFactor = 0.1f;

// Forward declaration
class Player;

// Levels Class

class levels {
protected:
    char** lvl;
    int width, height;
    Texture wallTex1, wallTex2, backgroundTexture , coinTex;
    Sprite wallSprite1, wallSprite2, backgroundSprite, coinSprite;

    float targetCameraX = 0.0f;
    float currentCameraX = 0.0f;

    Player& player;

public:
    levels(Player& p);
    virtual ~levels();
    virtual void set_level() = 0;
    virtual int get_width() = 0;
    virtual Player& get_player() { return player; }
    virtual char get_value(int x, int y) {
        if (x >= 0 && x < height && y >= 0 && y < width)
            return lvl[x][y];
        return '\0';
    }
    char** get_grid() { return lvl; }
    virtual void reset_camera_position() {
        targetCameraX = 0.0f;
        currentCameraX = 0.0f;
    }
    virtual void set_destroyVol(float vol) = 0;
    void display(RenderWindow& window);
};



// Player class
class Player {
protected:
    Texture birdTexture, readyTexture;
    Sprite birdSprite , readySprite;

    int currentIndex = 0;
    char** lvl = nullptr;
    int hp = 1;
    float x = 100, y = 100;
    float velocityY = 0;
    bool onGround = true;
    float gravity = 1.3f;
    float terminal_Velocity = 20;
    float jumpStrength = -10.0f;
    int screen_x = 1200;
    int screen_y = 900;
    float raw_img_x = 18;  
    float raw_img_y = 18;  
    float scale_x = 2.5f, scale_y = 2.5f;
    int Pheight = raw_img_y * scale_y;
    int Pwidth = raw_img_x * scale_x;
    int hit_box_factor_x = 2 * scale_x; 
    int hit_box_factor_y = 2 * scale_y;  
    const int cell_size = 64;
    Clock jumpClock;
    bool is_pause = true;
    float current_speed = 5.0f;
    int score = 0;
    Font scoreFont;
    Text scoreText;
   
    SoundBuffer jumpBuffer, coinBuffer, dieBuffer;
    Sound jumpSound, coinSound, dieSound;


public:
    Player() {
        //Just setting up and loading all the texutres , sprites and sounds from the files


        // Create a simple colored rectangle if bird.png doesn't exist
        if (!birdTexture.loadFromFile("Data/bird.png")) {
            // Create a simple texture programmatically using actual bird size
            Image img;
            img.create(raw_img_x, raw_img_y, Color::Yellow);
            birdTexture.loadFromImage(img);
        }
        birdSprite.setTexture(birdTexture);
        birdSprite.setScale(scale_x, scale_y);

        if (!scoreFont.loadFromFile("Data/Montserrat-Regular.ttf")) {
            cout << "Error loading font!" << endl;
        }
        scoreText.setFont(scoreFont);
        scoreText.setCharacterSize(40);
        scoreText.setFillColor(Color::White);
        scoreText.setPosition(40, 40); 
        scoreText.setStyle(Text::Bold);

        if (!readyTexture.loadFromFile("Data/ready.png")) {
            cout << "Error loading ready.png" << endl;
        }
        readySprite.setTexture(readyTexture);
        readySprite.setPosition(400 - readyTexture.getSize().x / 2, 300);
        readySprite.setScale(4, 4);

        //Loading sounds
        jumpBuffer.loadFromFile("Data/Global/jump.wav");
        jumpSound.setBuffer(jumpBuffer);
        jumpSound.setVolume(20);
        dieBuffer.loadFromFile("Data/Global/Hurt.wav");
        dieSound.setBuffer(dieBuffer);
        coinBuffer.loadFromFile("Data/Global/Ring.wav");
        coinSound.setBuffer(coinBuffer);

    }

    void move(bool is_right) {
        /*
          The basic of move is simple it is that the bird is paused at the specific location on the screen so when the space bar is pressed
          the bird start to move and it continuously move by its own slowly the only thing you can control is its height that can be done by
          space bar so when the space bar is pressed the height of the bird decreases but the gravity is always acting upon it means that it 
          autoatically keep on falling down
        */

        if (Keyboard::isKeyPressed(Keyboard::Space)) {
            if (is_pause) {
                is_pause = false;
                velocityY = jumpStrength;
            }
            else if (jumpClock.getElapsedTime().asMilliseconds() > 100) {
                if(velocityY > 0)
                    velocityY = jumpStrength;
                jumpSound.play();
                jumpClock.restart();
            }
        }
        if (!is_pause) {
            x += current_speed;
        }
    }

    void applyGravity() {
        // Simply if the game has been started by space bar so it always keep on increasing the y coordinate and when it falls out of screen player dies

        if (is_pause) return;
        y += velocityY;
        velocityY += gravity;
        if (velocityY > terminal_Velocity)
            velocityY = terminal_Velocity;

        // Check collision with level boundaries
        if (y + Pheight > screen_y) {
            y = screen_y - Pheight;
            velocityY = 0;
            onGround = true;
        }

        // Kill if bird falls out of level
        if (y > (12 * cell_size)) {
            hp = 0;
        }

        // Check collision with obstacles
        checkCollisions();
    }

    void checkCollisions() {
        if (!lvl) return;

        // Calculating the four corners of the bird
        float birdLeft = x + hit_box_factor_x;
        float birdRight = x + Pwidth - hit_box_factor_x;
        float birdTop = y + hit_box_factor_y - 64; // Subtacting one cell as to handle the bird moving inside the pillar
        float birdBottom = y + Pheight - hit_box_factor_y;

        // Calculating the four corners of grid so that the value stored at that location can be compared
        int gridLeft = (int)(birdLeft / cell_size);
        int gridRight = (int)(birdRight / cell_size);
        int gridTop = (int)(birdTop / cell_size);
        int gridBottom = (int)(birdBottom / cell_size);

        // Now checking the collision of bird with the pillars represented by w and s and with coin represented by c
        for (int i = gridTop; i <= gridBottom; i++) {
            for (int j = gridLeft; j <= gridRight; j++) {
                if (i >= 0 && i < 14 && j >= 0) {
                    char tile = get_value(i, j);
                    if (tile == 'w' || tile == 's') {
                        float tileLeft = j * cell_size;
                        float tileRight = (j + 1) * cell_size;
                        float tileTop = i * cell_size;
                        float tileBottom = (i + 1) * cell_size;

                        if (birdRight > tileLeft && birdLeft < tileRight &&
                            birdBottom > tileTop && birdTop < tileBottom) {
                            dieSound.play();
                            hp = 0; // If collision happens than set hp to 0 as the player dies
                            return;
                        }
                    }
                    if (tile == 'c') {
                        //Checking the collision with coin and adding the score accordingly
                        float tileLeft = j * cell_size;
                        float tileRight = (j + 1) * cell_size;
                        float tileTop = i * cell_size;
                        float tileBottom = (i + 1) * cell_size;

                        if (birdRight > tileLeft && birdLeft < tileRight &&
                            birdBottom > tileTop && birdTop < tileBottom) {
                            set_value(i, j);
                            coinSound.play();
                            score += 10;
                            scoreText.setString("Score: " + std::to_string(score));
                            cout << score << endl;
                            return;
                        }
                    }
                }
            }
        }

    }



    void draw(RenderWindow& window, float offsetX = 0) {
        birdSprite.setPosition(x - offsetX, y);
        window.draw(birdSprite);

        // Show score
        window.draw(scoreText);

        //  Show "ready" image if game is paused
        if (is_pause) {
            window.draw(readySprite);
        }
    }


    // Getters and Setters

    char get_value(int x, int y) {
        if (lvl && x >= 0 && x < 14 && y >= 0)
            return lvl[x][y];
        return '\0';
    }
    Text get_score()
    {
        return scoreText;
    }
    int getPoints()
    {
        return score;
    }
    void setScore(int x)
    {
        score = x;
    }
    void set_value(int x, int y)
    {
        lvl[x][y] = '/0';
    }
    void setLevel(char** newLevel, int lev) {
        lvl = newLevel;
    }
    void setPause()
    {
        is_pause = true;

    }
    float get_x(int index = 0) const { return x; }
    float get_y(int index = 0) const { return y; }
    void set_x(float nx) { x = nx; }
    void set_y(float ny) { y = ny; }
    bool check_alive() { return hp > 0; }
    Sprite getSpriteByIndex(int index) { 
        if (index == 1)
            return birdSprite;
        else
            return readySprite;
    }
    int get_currentIndex() { return currentIndex; }
    bool get_isPaused() { return is_pause; }

};

// Implementation of levels constructor and destructor
levels::levels(Player& p) : lvl(nullptr), width(0), height(14), player(p) {}

levels::~levels() {
    if (lvl) {
        for (int i = 0; i < height; i++)
            delete[] lvl[i];
        delete[] lvl;
    }
}

void levels::display(RenderWindow& window) {
    // Create simple background if texture doesn't exist and then displaying the background by handling the offset due to camera movement too
    if (backgroundTexture.getSize().x == 0) {
        Image bgImg;
        bgImg.create(1200, 900, Color::Cyan);
        backgroundTexture.loadFromImage(bgImg);
        backgroundSprite.setTexture(backgroundTexture);
    }
    int bgWidth = backgroundTexture.getSize().x;
    int repeatCount = (window.getSize().x / bgWidth) + 2;
    for (int i = 0; i < repeatCount; ++i) {
        backgroundSprite.setPosition(-int(currentCameraX * 0.5f) % bgWidth + i * bgWidth, 0);
        window.draw(backgroundSprite);
    }

    // Camera following logic as only 20 columns are displayed on the screen and once we move further then handling to displays the forward columns
    int playerColumn = player.get_x(player.get_currentIndex()) / cell_size;
    int targetStartColumn = playerColumn - 9;
    if (targetStartColumn < 0) targetStartColumn = 0;
    targetCameraX = targetStartColumn * cell_size;
    currentCameraX += (targetCameraX - currentCameraX) * cameraLerpFactor;
    int startColumn = int(currentCameraX / cell_size);
    int endColumn = startColumn + 19;
    if (endColumn >= width) endColumn = width - 1;
    if (width > 20 && endColumn == width - 1) {
        startColumn = width - 20;
        if (startColumn < 0) startColumn = 0;
        currentCameraX = startColumn * cell_size;
    }
    float xOffset = currentCameraX;


    // Drawing wall tiles based on level grid and the coin sprite too
    for (int i = 0; i < height; i++) {
        for (int j = startColumn; j <= endColumn; j++) {
            if (j < width) {
                char tile = lvl[i][j];
                if (tile == 'w') {
                    wallSprite1.setPosition(j * cell_size - xOffset, i * cell_size);
                    window.draw(wallSprite1);
                }
                else if (tile == 's') {
                    wallSprite2.setPosition(j * cell_size - xOffset, i * cell_size);
                    window.draw(wallSprite2);
                }
                else if (tile == 'c')
                {
                    coinSprite.setPosition(j * cell_size - xOffset, i * cell_size);
                    window.draw(coinSprite);
                }
            }
        }
    }

    // Drawing player and score 
    Sprite playerSprite = player.getSpriteByIndex(1);
    Sprite readySprite = player.getSpriteByIndex(2);
    float originalX = player.get_x(0);
    float originalY = player.get_y(0);
    playerSprite.setPosition(originalX - xOffset, originalY);
    window.draw(playerSprite);
    if(player.get_isPaused())
        window.draw(readySprite);
    Text score = player.get_score();
    window.draw(score);
}

// Level 1 class inherited from the levels class

class level1 : public levels {
public:
    level1(Player& p) : levels(p) {
        // Simply setting up the sprites and textures loading them from the files
        width = 200;

        // Load wall textures from files
        if (!wallTex1.loadFromFile("Data/wallUp.png")) {
            cout << "Warning: Could not load wallUp.png, using default texture" << endl;
         
        }
        wallSprite1.setTexture(wallTex1);
        wallSprite1.setScale(2.5, 1);

        if (!wallTex2.loadFromFile("Data/wallDown.png")) {
            cout << "Warning: Could not load wallDown.png, using default texture" << endl;
           
        }
        wallSprite2.setTexture(wallTex2);
        wallSprite2.setScale(2.5,1);

        if (!coinTex.loadFromFile("Data/coin.png")) {
            cout << "Warning: Could not load wallDown.png, using default texture" << endl;
        }
        coinSprite.setTexture(coinTex);
        coinSprite.setScale(1.5, 1.5 );


        // Load background texture
        if (!backgroundTexture.loadFromFile("Data/backgroundImg.png")) {
            cout << "Warning: Could not load backgroundImg.png, using default background" << endl; // Create fallback background
            Image bgImg;
            bgImg.create(1200, 900, Color::Cyan);
            backgroundTexture.loadFromImage(bgImg);
        }
        backgroundSprite.setTexture(backgroundTexture);
        Vector2u texSize = backgroundTexture.getSize(); // 145 x 253
        float scaleX = 1200.0f / texSize.x;
        float scaleY = 900.0f / texSize.y;
        backgroundSprite.setScale(scaleX, scaleY); // Stretch to fit screen

        lvl = new char* [height];
        for (int i = 0; i < height; i++) {
            lvl[i] = new char[width];
            for (int j = 0; j < width; j++) {
                lvl[i][j] = '\0';
            }
        }
    }

    void set_level() override {

        // Clearing the level first
        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width; j++) {
                lvl[i][j] = '\0';
            }
        }

       // Now creating the pillars obstacles and setting the coins between them

        for (int j = 10; j < width - 10; j += 12) {
            // Creating upper wall section (rows 1-3)
            for (int i = 0; i <= 3; i++) {
                lvl[i][j] = 'w';
               
            }

            //Creating the coins between the upper and lower pillar
            lvl[6][j] = 'c';
            lvl[7][j] = 'c';

            // Rows 4 to 7 are empty so that the bird can pass through them

            // Creating lower spike section (rows 8-11)
            for (int i = 8; i <= 11; i++) {
                lvl[i][j] = 's';
               
            }

            if ((j + 6) < width)
            {
                // Creating upper wall section (rows 1-2)
                for (int i = 0; i <= 2; i++) {
                    lvl[i][j + 6] = 'w';

                }

                //Creating the coins between the upper and lower pillar
                lvl[6][j+6] = 'c';
                lvl[7][j+6] = 'c';

                // Rows 3 to 6 are empty so that the bird can pass through them

                // Creating lower spike section (rows 8-11)
                for (int i = 7; i <= 11; i++) {
                    lvl[i][j + 6] = 's';

                }
            }
           

        }

        // Left boundary
        for (int i = 0; i < height; i++) {
            lvl[i][0] = 'w';
        }
       
    }

    int get_width() override { return width; }
    void set_destroyVol(float) override {}
};

class level2 : public levels {
public:
    level2(Player& p) : levels(p) {
        // Simply setting up the sprites and textures loading them from the files

        width = 200;

        // Load wall and coin textures from files
        if (!wallTex1.loadFromFile("Data/wallUp2.png")) {
            cout << "Warning: Could not load wallUp.png, using default texture" << endl;
        }
        wallSprite1.setTexture(wallTex1);
        wallSprite1.setScale(2.5, 1);
        if (!wallTex2.loadFromFile("Data/wallDown2.png")) {
            cout << "Warning: Could not load wallDown.png, using default texture" << endl;
        }
        wallSprite2.setTexture(wallTex2);
        wallSprite2.setScale(2.5, 1);
        if (!coinTex.loadFromFile("Data/coin2.png")) {
            cout << "Warning: Could not load wallDown.png, using default texture" << endl;
        }
        coinSprite.setTexture(coinTex);
        coinSprite.setScale(1.5, 1.5);
        // Load background texture
        if (!backgroundTexture.loadFromFile("Data/background2.png")) {
            cout << "Warning: Could not load backgroundImg.png, using default background" << endl;
            Image bgImg;
            bgImg.create(1200, 900, Color::Cyan);
            backgroundTexture.loadFromImage(bgImg);
        }
        backgroundSprite.setTexture(backgroundTexture);
        Vector2u texSize = backgroundTexture.getSize(); 
        float scaleX = 1200.0f / texSize.x;
        float scaleY = 900.0f / texSize.y;
        backgroundSprite.setScale(scaleX, scaleY); 


        // Initialize level grid
        lvl = new char* [height];
        for (int i = 0; i < height; i++) {
            lvl[i] = new char[width];
            for (int j = 0; j < width; j++) {
                lvl[i][j] = '\0';
            }
        }
    }

    void set_level() override {
        // Clear the level first
        for (int i = 0; i < height; i++) {
            for (int j = 0; j < width; j++) {
                lvl[i][j] = '\0';
            }
        }

        // Now creating the pillars obstacles and setting the coins between them
        for (int j = 10; j < width - 12; j += 15) {
            
            for (int i = 0; i <= 3; i++) {
                lvl[i][j] = 'w';

            }

            lvl[6][j] = 'c';

            for (int i = 8; i <= 11; i++) {
                lvl[i][j] = 's';

            }

            if ((j + 5) < width)
            {
                for (int i = 0; i <= 2; i++) {
                    lvl[i][j + 5] = 'w';

                }

                lvl[5][j + 5] = 'c';
                lvl[6][j + 5] = 'c';

                for (int i = 7; i <= 11; i++) {
                    lvl[i][j + 5] = 's';

                }
            }
            if ((j + 10) < width)
            {
                for (int i = 0; i <= 5; i++) {
                    lvl[i][j + 10] = 'w';

                }

                lvl[8][j + 10] = 'c';

                for (int i = 9; i <= 11; i++) {
                    lvl[i][j + 10] = 's';

                }
            }


        }

        // Left boundary
        for (int i = 0; i < height; i++) {
            lvl[i][0] = 'w';
        }
    }

    int get_width() override { return width; }
    void set_destroyVol(float) override {}
};

class Game {
private:
    RenderWindow window;
    Menu menu;
    Player* player;
    levels* lvl;
    levels* temp;
    bool gameStarted = false;
    bool is_level2 = false;
    int cell_size = 64;
    Music level1Mus;
    Music level2Mus;


public:
    Game() : window(VideoMode(1200, 900), "Flappy Bird Clone", Style::Close) {
        //Just setting the things up 

        window.setVerticalSyncEnabled(true);
        window.setFramerateLimit(60);

        player = new Player();
        lvl = new level1(*player);
        temp = new level2(*player);
        lvl->set_level();
        player->setLevel(lvl->get_grid(), 1);
        menu.readScoresFromFile();
    }

    ~Game() {

        delete player;
        delete lvl;
        delete temp;
    }

    string intToString(int num) {
        stringstream ss;
        ss << num;
        return ss.str();
    }

    int gameOverScreen(RenderWindow& window, const string& playerName, int score) {
        /*
          Just displaying the game over screen and also the text having the instructions of what to do or what options you can chose and also
          the final score you have scored so in this functions there is mainly the loading and setting up of the fonts and images and then 
          displaying it on the screen
        */

        menu.addScore(playerName, score);

        // Loading font
        Font font;
        if (!font.loadFromFile("Data/Montserrat-Regular.ttf")) {
            cout << "Error loading font!" << endl;
            return -1;
        }

        // Loading Game Over Image
        Texture gameOverTexture;
        if (!gameOverTexture.loadFromFile("Data/gameOver.png")) {
            cout << "Error loading game over image!" << endl;
            return -1;
        }

        Sprite gameOverSprite;
        gameOverSprite.setTexture(gameOverTexture);
        float scaleX = 1200.0f / gameOverTexture.getSize().x;
        float scaleY = 900.0f / gameOverTexture.getSize().y;
        gameOverSprite.setScale(scaleX, scaleY);
        gameOverSprite.setPosition(0, 0);


        // Setting up the score text font and everything
        Text scoreText;
        scoreText.setFont(font);
        scoreText.setString("Final Score: " + intToString(score));
        scoreText.setCharacterSize(40);
        scoreText.setFillColor(Color::Black);
        scoreText.Bold;
        scoreText.setPosition(450, 700); 

        // Setting up the instructions font and everything
        Text restartText;
        restartText.setFont(font);
        restartText.setString("Press R to return to Menu\nPress X to Exit");
        restartText.setCharacterSize(30);
        restartText.setFillColor(Color::Black);
        scoreText.Bold;
        restartText.setPosition(435, 600); 

        while (window.isOpen()) {
            Event ev;
            while (window.pollEvent(ev)) {
                if (ev.type == Event::Closed) {
                    window.close();
                    return -1;
                }
                if (ev.type == Event::KeyPressed) {
                    if (ev.key.code == Keyboard::R) {
                        return 1;
                    }
                    if (ev.key.code == Keyboard::X) {
                        window.close();
                        return -1;
                    }
                }
            }

            window.clear();
            window.draw(gameOverSprite);     
            window.draw(scoreText);          
            window.draw(restartText);
            window.display();
        }

        return -1;
    }

    int youWinScreen(RenderWindow& window, const string& playerName, int score) {
        // Same as game over function

        menu.addScore(playerName, score);

        // Loading font
        Font font;
        if (!font.loadFromFile("Data/Montserrat-Regular.ttf")) {
            cout << "Error loading font!" << endl;
            return -1;
        }

        // Loading You Win Image
        Texture gameOverTexture;
        if (!gameOverTexture.loadFromFile("Data/youWin.png")) {
            cout << "Error loading game over image!" << endl;
            return -1;
        }
        Sprite gameOverSprite;
        gameOverSprite.setTexture(gameOverTexture);
        float scaleX = 1200.0f / gameOverTexture.getSize().x;
        float scaleY = 900.0f / gameOverTexture.getSize().y;
        gameOverSprite.setScale(scaleX, scaleY);
        gameOverSprite.setPosition(0, 0);

        Text scoreText;
        scoreText.setFont(font);
        scoreText.setString("Final Score: " + intToString(score));
        scoreText.setCharacterSize(40);
        scoreText.setFillColor(Color::Black);
        scoreText.Bold;
        scoreText.setPosition(450, 700); 

        Text restartText;
        restartText.setFont(font);
        restartText.setString("Press R to return to Menu\nPress X to Exit");
        restartText.setCharacterSize(30);
        restartText.setFillColor(Color::Black);
        scoreText.Bold;
        restartText.setPosition(435, 600); 

        while (window.isOpen()) {
            Event ev;
            while (window.pollEvent(ev)) {
                if (ev.type == Event::Closed) {
                    window.close();
                    return -1;
                }
                if (ev.type == Event::KeyPressed) {
                    if (ev.key.code == Keyboard::R) {
                        return 1;
                    }
                    if (ev.key.code == Keyboard::X) {
                        window.close();
                        return -1;
                    }
                }
            }

            window.clear();
            window.draw(gameOverSprite);    
            window.draw(scoreText);         
            window.draw(restartText);
            window.display();
        }

        return -1;
    }



    void startNewGame() {

        is_level2 = false;

        lvl->set_level();
        player->setLevel(lvl->get_grid(), 1);
        gameStarted = true;

        // Loading the music for the levels
        level1Mus.openFromFile("Data/Global/level1.ogg");
        level1Mus.setVolume(150);
        level2Mus.openFromFile("Data/Global/level2.ogg");
        level2Mus.setVolume(150);


        level1Mus.play();
        
        while (window.isOpen() && gameStarted) {
            Event event;
            while (window.pollEvent(event)) {
                if (event.type == Event::Closed) {
                    window.close();
                    return;
                }
            }

            // Handling escape key to return to the menu
            if (Keyboard::isKeyPressed(Keyboard::Escape)) {
                int menuStatus = loadMenu();
                if (menuStatus == -1) {
                    window.close();
                    return;
                }
                else if (menuStatus == 1) {
                    startNewGame();
                    return;
                }
                else {
                    continue;
                }
            }

            // Calling move and apply gravity function all the time
            player->move(true);
            player->applyGravity();

            // If player dies then displaying game over screen 
            if (!player->check_alive()) {
                cout << "Game Over!" << endl;

                string playerName = menu.getPlayerName();
                int finalScore = player->getPoints();

                int status = gameOverScreen(window, playerName, finalScore);
                cout << "Score " << finalScore << " added to leaderboard for " << playerName << endl;

                if (status == 1) {
                    gameStarted = false;
                    return;
                }
                else if (status == -1) {
                    window.close();
                    return;
                }
            }

            // Level changing from 1 to 2 if we have reached the end so setting up the things of player for level 2
            if ((player->get_x() > 180 * cell_size) && !is_level2)
            {
                int totalScore = player->getPoints();

                // Delete old level and create new level2
                delete lvl;
                lvl = new level2(*player);
                lvl->set_level();  

                // Reseting the position of the player and also setting the score of level 1 on level 2 and changing the music 
                player->set_x(2 * cell_size);  
                player->set_y(5 * cell_size);  
                player->setPause();

                player->setScore(totalScore);
                player->setLevel(lvl->get_grid(), 2);

                is_level2 = true;
                level1Mus.pause();
                level2Mus.play();
                cout << "Switched to Level 2!" << endl;

            }
            else if ((player->get_x() > 180 * cell_size) && is_level2)
            {
                //Now if level 2 has been crossed by the player then displaying you win screen and ending the game
                cout << "You Win!" << endl;

                string playerName = menu.getPlayerName();
                int finalScore = player->getPoints();

                int status = youWinScreen(window, playerName, finalScore);
                cout << "Score " << finalScore << " added to leaderboard for " << playerName << endl;

                if (status == 1) {
                    gameStarted = false;
                    return;
                }
                else if (status == -1) {
                    window.close();
                    return;
                }
            }

            // Rendering the screen
            window.clear();
            lvl->display(window);
            window.display();
        }
    }

    void run() {
        // Handling the menu
        while (window.isOpen()) {
            int menuStatus = loadMenu();

            if (menuStatus == -1) {
                window.close();
                return;
            }
            else if (menuStatus == 1) {
                startNewGame();
            }
            else if (menuStatus == 2) {
                startNewGame();
            }
            else if (menuStatus == 3) {
                menu.displayLeaderboard(window);
            }
        }
    }

    int loadMenu() {
        int selected = menu.show(window);

        if (selected == 1) {
            return 1; // New Game
        }
        else if (selected == 2) {
            return 2; // Continue
        }
        else if (selected == 3) {
            menu.displayLeaderboard(window);
            return 3;//Leaderboard
        }
        else if (selected == 4) {
            return -1; // Exit
        }
        else {
            return -1;
        }
    }
};



int main() {
    Game game;
    game.run();
    return 0;
}